import { motion, useReducedMotion } from 'framer-motion';
import { InsulatorCloud } from '../canvas/InsulatorCloud';
import { SectionLabel, Ticks } from '../components/Bits';
import { TileGlyph } from '../components/TileGlyph';
import { SOLVE } from '../content';
import { anchor } from '../lib/scroll';
import { LineReveal } from '../motion/LineReveal';
import { Reveal, RevealGroup, RevealItem } from '../motion/Reveal';
import { EASE, VIEWPORT } from '../motion/variants';

export function Solve() {
  const reduce = useReducedMotion();
  return (
    <section id="solve" className="relative py-20 md:py-28" aria-labelledby="solve-title">
      <div className="wrap">
        <SectionLabel index={2} text={SOLVE.label} />
        <LineReveal
          id="solve-title"
          lines={splitTitle(SOLVE.title)}
          className="mt-8 max-w-[22ch] text-[clamp(32px,4.4vw,64px)] font-light leading-[1.05] tracking-[-0.03em]"
        />

        {/* Tiles: title + abstract graphic only, no explanatory text */}
        <RevealGroup className="mt-14 grid grid-cols-2 gap-px border border-line bg-line md:mt-20 md:grid-cols-4" step={0.1}>
          {SOLVE.tiles.map((t, i) => (
            <RevealItem key={t} className="group relative flex h-48 flex-col justify-between bg-bg p-4 transition-colors duration-500 hover:bg-surface md:h-64 md:p-5">
              <div className="flex items-center justify-between">
                <span className="label">{String(i + 1).padStart(2, '0')}</span>
                <span className="h-1.5 w-1.5 rounded-full bg-line-strong transition-colors duration-500 group-hover:bg-accent" />
              </div>
              <div className="mx-auto h-24 w-full max-w-[200px] md:h-28">
                <TileGlyph kind={i} />
              </div>
              <h3 className="font-mono text-[11px] uppercase leading-snug tracking-[0.12em] text-ink md:text-[12px]">{t}</h3>
            </RevealItem>
          ))}
        </RevealGroup>

        {/* In focus panel */}
        <motion.div
          initial={reduce ? false : { opacity: 0, y: 40 }}
          whileInView={{ opacity: 1, y: 0 }}
          viewport={VIEWPORT}
          transition={{ duration: 1.1, ease: EASE }}
          className="ticks relative mt-6 grid overflow-hidden border border-line bg-surface md:mt-8 lg:grid-cols-12"
        >
          <Ticks />
          <div className="relative z-10 flex flex-col justify-between gap-10 p-6 md:p-10 lg:col-span-5 lg:p-12">
            <div>
              <Reveal className="inline-flex items-center gap-3">
                <span className="relative flex h-2 w-2">
                  <span className="absolute inset-0 rounded-full bg-accent" style={{ animation: 'ping-ring 2.4s var(--ease) infinite' }} />
                  <span className="relative h-2 w-2 rounded-full bg-accent" />
                </span>
                <span className="label text-ink">{SOLVE.focus.label}</span>
              </Reveal>
              <LineReveal
                as="h3"
                lines={[SOLVE.focus.title]}
                className="mt-6 text-[clamp(30px,3.4vw,48px)] font-light leading-[1.05] tracking-[-0.03em]"
              />
              <Reveal as="p" delay={0.15} className="mt-6 max-w-md text-[16px] leading-relaxed text-muted">
                {SOLVE.focus.body}
              </Reveal>
            </div>
            <Reveal className="label hidden gap-6 lg:flex">
              <span>Fig. 01</span>
              <span className="text-line-strong">/</span>
              <span>Point cloud</span>
            </Reveal>
          </div>
          <div className="relative h-[380px] border-t border-line md:h-[480px] lg:col-span-7 lg:h-[600px] lg:border-l lg:border-t-0">
            <div className="absolute inset-0 bg-[radial-gradient(ellipse_at_center,rgba(30,107,232,0.10),transparent_65%)]" />
            <div className="absolute inset-0 bg-[linear-gradient(var(--line)_1px,transparent_1px),linear-gradient(90deg,var(--line)_1px,transparent_1px)] bg-[size:48px_48px] opacity-30" />
            <InsulatorCloud className="relative" />
          </div>
        </motion.div>

        <Reveal className="mt-10 flex md:justify-end">
          <a href="#contact" onClick={anchor('contact')} className="group label inline-flex items-center gap-3 text-ink/80 hover:text-ink">
            {SOLVE.closing}
            <span className="inline-block text-accent transition-transform duration-500 group-hover:translate-x-1">→</span>
          </a>
        </Reveal>
      </div>
    </section>
  );
}

/** Two balanced lines for the section title on wide screens. */
function splitTitle(t: string) {
  const words = t.split(' ');
  const mid = Math.ceil(words.length / 2);
  return [words.slice(0, mid).join(' '), words.slice(mid).join(' ')];
}
